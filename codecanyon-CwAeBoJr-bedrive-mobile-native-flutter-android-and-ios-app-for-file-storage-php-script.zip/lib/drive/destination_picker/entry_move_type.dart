enum EntryMoveType {
  move,
  copy,
}
