// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../i18n/localization_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localizationHash() => r'b078ac599f075c48808a631a7e46da7719e15953';

/// See also [localization].
@ProviderFor(localization)
final localizationProvider = Provider<Localizer>.internal(
  localization,
  name: r'localizationProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$localizationHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef LocalizationRef = ProviderRef<Localizer>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
