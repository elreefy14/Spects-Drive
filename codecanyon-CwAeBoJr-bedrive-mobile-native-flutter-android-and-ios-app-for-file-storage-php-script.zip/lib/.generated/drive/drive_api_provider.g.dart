// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../drive/drive_api_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$driveApiHash() => r'091f14d2b6717c8940aa433e8f37020b33879f86';

/// See also [driveApi].
@ProviderFor(driveApi)
final driveApiProvider = FutureProvider<DriveApi>.internal(
  driveApi,
  name: r'driveApiProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$driveApiHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef DriveApiRef = FutureProviderRef<DriveApi>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
