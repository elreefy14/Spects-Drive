// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../drive/search/search_filters_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$searchFiltersHash() => r'490e39d78a60be656025b6d49fa1883390cdd4e4';

/// See also [SearchFilters].
@ProviderFor(SearchFilters)
final searchFiltersProvider =
    AutoDisposeNotifierProvider<SearchFilters, SearchFiltersValue>.internal(
  SearchFilters.new,
  name: r'searchFiltersProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$searchFiltersHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SearchFilters = AutoDisposeNotifier<SearchFiltersValue>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
