// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../../drive/transfers/manager/transfers_manager_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$transfersManagerHash() => r'd3b31fd1178bb4059b4a3d87b227ac60a529b31f';

/// See also [transfersManager].
@ProviderFor(transfersManager)
final transfersManagerProvider =
    AutoDisposeProvider<TransfersManagerContract>.internal(
  transfersManager,
  name: r'transfersManagerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$transfersManagerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef TransfersManagerRef = AutoDisposeProviderRef<TransfersManagerContract>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
