// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../drive/offline/api_response_cache.dart';

// ignore_for_file: type=lint
mixin _$ApiResponseCacheDaoMixin on DatabaseAccessor<AppDatabase> {
  $ApiResponseCacheTableTable get apiResponseCacheTable =>
      attachedDatabase.apiResponseCacheTable;
}
