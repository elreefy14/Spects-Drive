// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../drive/offline/offlined_entries_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$offlinedEntriesControllerHash() =>
    r'e70e5f6324091b6ca0e608bceedaaaabf90bfef3';

/// See also [OfflinedEntriesController].
@ProviderFor(OfflinedEntriesController)
final offlinedEntriesControllerProvider =
    AsyncNotifierProvider<OfflinedEntriesController, List<int>>.internal(
  OfflinedEntriesController.new,
  name: r'offlinedEntriesControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$offlinedEntriesControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OfflinedEntriesController = AsyncNotifier<List<int>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
