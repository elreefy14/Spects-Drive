// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../drive/offline/offlined_entries_path_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$offlinedEntriesPathHash() =>
    r'32781166f8583a8c629e8534cca567f0d5bdcbe8';

/// See also [OfflinedEntriesPath].
@ProviderFor(OfflinedEntriesPath)
final offlinedEntriesPathProvider =
    AsyncNotifierProvider<OfflinedEntriesPath, String>.internal(
  OfflinedEntriesPath.new,
  name: r'offlinedEntriesPathProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$offlinedEntriesPathHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OfflinedEntriesPath = AsyncNotifier<String>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
