// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../drive/drive_state_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$driveStateHash() => r'7c1ed10bffd8561e7070cf6ba477fd4e422b66a3';

/// See also [DriveState].
@ProviderFor(DriveState)
final driveStateProvider =
    NotifierProvider<DriveState, DriveStateValue>.internal(
  DriveState.new,
  name: r'driveStateProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$driveStateHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$DriveState = Notifier<DriveStateValue>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
