// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../drive/notifications/firebase_messaging_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$firebaseMessagingHash() => r'68a59ac967021f692681c01f92f6331d9e6a1404';

/// See also [firebaseMessaging].
@ProviderFor(firebaseMessaging)
final firebaseMessagingProvider = FutureProvider<FirebaseMessaging?>.internal(
  firebaseMessaging,
  name: r'firebaseMessagingProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$firebaseMessagingHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef FirebaseMessagingRef = FutureProviderRef<FirebaseMessaging?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
