// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../drive/notifications/local_notifications_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localNotificationsHash() =>
    r'e51e1c8b2f38ad27f05f2fc8f0b53f8184d10a88';

/// See also [LocalNotifications].
@ProviderFor(LocalNotifications)
final localNotificationsProvider = NotifierProvider<LocalNotifications,
    FlutterLocalNotificationsPlugin>.internal(
  LocalNotifications.new,
  name: r'localNotificationsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$localNotificationsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$LocalNotifications = Notifier<FlutterLocalNotificationsPlugin>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
