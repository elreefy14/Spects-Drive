// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../../../../../drive/layout/drive_drawer/settings_screen/notification_section/notification_subscriptions_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$notificationSubscriptionsHash() =>
    r'186293f8ba653e9e1372190683d08655fe69ff3d';

/// See also [notificationSubscriptions].
@ProviderFor(notificationSubscriptions)
final notificationSubscriptionsProvider =
    AutoDisposeFutureProvider<NotificationSubscriptions>.internal(
  notificationSubscriptions,
  name: r'notificationSubscriptionsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$notificationSubscriptionsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef NotificationSubscriptionsRef
    = AutoDisposeFutureProviderRef<NotificationSubscriptions>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
