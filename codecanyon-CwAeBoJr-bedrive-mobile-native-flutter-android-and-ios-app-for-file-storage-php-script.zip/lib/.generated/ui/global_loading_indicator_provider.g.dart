// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../ui/global_loading_indicator_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$globalLoadingIndicatorHash() =>
    r'c6238a49172bf7d9840c43920dd9e44082a24880';

/// See also [GlobalLoadingIndicator].
@ProviderFor(GlobalLoadingIndicator)
final globalLoadingIndicatorProvider = NotifierProvider<GlobalLoadingIndicator,
    GlobalLoadingIndicatorState>.internal(
  GlobalLoadingIndicator.new,
  name: r'globalLoadingIndicatorProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$globalLoadingIndicatorHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$GlobalLoadingIndicator = Notifier<GlobalLoadingIndicatorState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
