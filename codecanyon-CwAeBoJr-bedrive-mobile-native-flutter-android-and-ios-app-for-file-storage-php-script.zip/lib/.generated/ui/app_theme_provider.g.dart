// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../ui/app_theme_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$appThemeHash() => r'932d56b4d5a69408e4a7545d2ed945db351b1448';

/// See also [appTheme].
@ProviderFor(appTheme)
final appThemeProvider = FutureProvider<
    ({ThemeData dark, ThemeData light, ThemeMode selectedTheme})>.internal(
  appTheme,
  name: r'appThemeProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$appThemeHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AppThemeRef = FutureProviderRef<
    ({ThemeData dark, ThemeData light, ThemeMode selectedTheme})>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
