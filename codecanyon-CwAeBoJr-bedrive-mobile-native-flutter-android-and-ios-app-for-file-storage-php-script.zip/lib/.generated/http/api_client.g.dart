// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../http/api_client.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$apiClientHash() => r'5bf01b182a65db0de60502bbfd0062a849d38cac';

/// See also [apiClient].
@ProviderFor(apiClient)
final apiClientProvider = FutureProvider<ApiHttpClient>.internal(
  apiClient,
  name: r'apiClientProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$apiClientHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef ApiClientRef = FutureProviderRef<ApiHttpClient>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
