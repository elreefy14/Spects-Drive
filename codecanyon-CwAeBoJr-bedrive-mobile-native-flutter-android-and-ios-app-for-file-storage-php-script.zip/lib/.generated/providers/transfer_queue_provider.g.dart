// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../providers/transfer_queue_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$transferQueueHash() => r'30a8ef117e6f0ae9a173e680a484cf002dd6c19b';

/// See also [TransferQueue].
@ProviderFor(TransferQueue)
final transferQueueProvider = AsyncNotifierProvider<TransferQueue,
    Map<String, TransferQueueItem>>.internal(
  TransferQueue.new,
  name: r'transferQueueProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$transferQueueHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$TransferQueue = AsyncNotifier<Map<String, TransferQueueItem>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
