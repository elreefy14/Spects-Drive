// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../bootstrap/bootstrap_data_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$bootstrapDataHash() => r'd504b9d0b5a0c437efdc36a64b63ac86ab095b65';

/// See also [bootstrapData].
@ProviderFor(bootstrapData)
final bootstrapDataProvider = FutureProvider<BootstrapData>.internal(
  bootstrapData,
  name: r'bootstrapDataProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$bootstrapDataHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef BootstrapDataRef = FutureProviderRef<BootstrapData>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
