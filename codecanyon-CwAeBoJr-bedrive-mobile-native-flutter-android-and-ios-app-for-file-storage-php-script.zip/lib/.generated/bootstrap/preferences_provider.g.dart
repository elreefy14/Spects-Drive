// GENERATED CODE - DO NOT MODIFY BY HAND

part of '../../bootstrap/preferences_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$preferencesHash() => r'6d48b2c508fba584cd2c6c136ea40f53e52f0b5e';

/// See also [preferences].
@ProviderFor(preferences)
final preferencesProvider =
    FutureProvider<SharedPreferencesRepository>.internal(
  preferences,
  name: r'preferencesProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$preferencesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef PreferencesRef = FutureProviderRef<SharedPreferencesRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
