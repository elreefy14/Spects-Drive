package com.vebto.bedrive_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
